```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

%matplotlib inline
```


```python
sales = pd.read_csv(
    "Sales.csv",
    parse_dates=['Date'])
```


```python
sales.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Day</th>
      <th>Year</th>
      <th>Customer_Age</th>
      <th>Order_Quantity</th>
      <th>Unit_Cost</th>
      <th>Unit_Price</th>
      <th>Profit</th>
      <th>Cost</th>
      <th>Revenue</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>113036.000000</td>
      <td>113036.000000</td>
      <td>113036.000000</td>
      <td>113036.000000</td>
      <td>113036.000000</td>
      <td>113036.000000</td>
      <td>113036.000000</td>
      <td>113036.000000</td>
      <td>113036.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>15.665753</td>
      <td>2014.401739</td>
      <td>35.919212</td>
      <td>11.901660</td>
      <td>267.296366</td>
      <td>452.938427</td>
      <td>285.051665</td>
      <td>469.318695</td>
      <td>754.370360</td>
    </tr>
    <tr>
      <th>std</th>
      <td>8.781567</td>
      <td>1.272510</td>
      <td>11.021936</td>
      <td>9.561857</td>
      <td>549.835483</td>
      <td>922.071219</td>
      <td>453.887443</td>
      <td>884.866118</td>
      <td>1309.094674</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>2011.000000</td>
      <td>17.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>2.000000</td>
      <td>-30.000000</td>
      <td>1.000000</td>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>8.000000</td>
      <td>2013.000000</td>
      <td>28.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>5.000000</td>
      <td>29.000000</td>
      <td>28.000000</td>
      <td>63.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>16.000000</td>
      <td>2014.000000</td>
      <td>35.000000</td>
      <td>10.000000</td>
      <td>9.000000</td>
      <td>24.000000</td>
      <td>101.000000</td>
      <td>108.000000</td>
      <td>223.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>23.000000</td>
      <td>2016.000000</td>
      <td>43.000000</td>
      <td>20.000000</td>
      <td>42.000000</td>
      <td>70.000000</td>
      <td>358.000000</td>
      <td>432.000000</td>
      <td>800.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>31.000000</td>
      <td>2016.000000</td>
      <td>87.000000</td>
      <td>32.000000</td>
      <td>2171.000000</td>
      <td>3578.000000</td>
      <td>15096.000000</td>
      <td>42978.000000</td>
      <td>58074.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
sales.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Day</th>
      <th>Month</th>
      <th>Year</th>
      <th>Customer_Age</th>
      <th>Age_Group</th>
      <th>Customer_Gender</th>
      <th>Country</th>
      <th>State</th>
      <th>Product_Category</th>
      <th>Sub_Category</th>
      <th>Product</th>
      <th>Order_Quantity</th>
      <th>Unit_Cost</th>
      <th>Unit_Price</th>
      <th>Profit</th>
      <th>Cost</th>
      <th>Revenue</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2013-11-26</td>
      <td>26</td>
      <td>November</td>
      <td>2013</td>
      <td>19</td>
      <td>Youth (&lt;25)</td>
      <td>M</td>
      <td>Canada</td>
      <td>British Columbia</td>
      <td>Accessories</td>
      <td>Bike Racks</td>
      <td>Hitch Rack - 4-Bike</td>
      <td>8</td>
      <td>45</td>
      <td>120</td>
      <td>590</td>
      <td>360</td>
      <td>950</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2015-11-26</td>
      <td>26</td>
      <td>November</td>
      <td>2015</td>
      <td>19</td>
      <td>Youth (&lt;25)</td>
      <td>M</td>
      <td>Canada</td>
      <td>British Columbia</td>
      <td>Accessories</td>
      <td>Bike Racks</td>
      <td>Hitch Rack - 4-Bike</td>
      <td>8</td>
      <td>45</td>
      <td>120</td>
      <td>590</td>
      <td>360</td>
      <td>950</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2014-03-23</td>
      <td>23</td>
      <td>March</td>
      <td>2014</td>
      <td>49</td>
      <td>Adults (35-64)</td>
      <td>M</td>
      <td>Australia</td>
      <td>New South Wales</td>
      <td>Accessories</td>
      <td>Bike Racks</td>
      <td>Hitch Rack - 4-Bike</td>
      <td>23</td>
      <td>45</td>
      <td>120</td>
      <td>1366</td>
      <td>1035</td>
      <td>2401</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2016-03-23</td>
      <td>23</td>
      <td>March</td>
      <td>2016</td>
      <td>49</td>
      <td>Adults (35-64)</td>
      <td>M</td>
      <td>Australia</td>
      <td>New South Wales</td>
      <td>Accessories</td>
      <td>Bike Racks</td>
      <td>Hitch Rack - 4-Bike</td>
      <td>20</td>
      <td>45</td>
      <td>120</td>
      <td>1188</td>
      <td>900</td>
      <td>2088</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2014-05-15</td>
      <td>15</td>
      <td>May</td>
      <td>2014</td>
      <td>47</td>
      <td>Adults (35-64)</td>
      <td>F</td>
      <td>Australia</td>
      <td>New South Wales</td>
      <td>Accessories</td>
      <td>Bike Racks</td>
      <td>Hitch Rack - 4-Bike</td>
      <td>4</td>
      <td>45</td>
      <td>120</td>
      <td>238</td>
      <td>180</td>
      <td>418</td>
    </tr>
  </tbody>
</table>
</div>




```python
sales.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 113036 entries, 0 to 113035
    Data columns (total 18 columns):
     #   Column            Non-Null Count   Dtype         
    ---  ------            --------------   -----         
     0   Date              113036 non-null  datetime64[ns]
     1   Day               113036 non-null  int64         
     2   Month             113036 non-null  object        
     3   Year              113036 non-null  int64         
     4   Customer_Age      113036 non-null  int64         
     5   Age_Group         113036 non-null  object        
     6   Customer_Gender   113036 non-null  object        
     7   Country           113036 non-null  object        
     8   State             113036 non-null  object        
     9   Product_Category  113036 non-null  object        
     10  Sub_Category      113036 non-null  object        
     11  Product           113036 non-null  object        
     12  Order_Quantity    113036 non-null  int64         
     13  Unit_Cost         113036 non-null  int64         
     14  Unit_Price        113036 non-null  int64         
     15  Profit            113036 non-null  int64         
     16  Cost              113036 non-null  int64         
     17  Revenue           113036 non-null  int64         
    dtypes: datetime64[ns](1), int64(9), object(8)
    memory usage: 15.5+ MB
    


```python
sales.shape
```




    (113036, 18)



*We'll analyze the Unit_Cost column:


```python
sales['Unit_Cost'].describe()
```




    count    113036.000000
    mean        267.296366
    std         549.835483
    min           1.000000
    25%           2.000000
    50%           9.000000
    75%          42.000000
    max        2171.000000
    Name: Unit_Cost, dtype: float64




```python
sales['Unit_Cost'].mean()
```




    267.296365759581




```python
sales['Unit_Cost'].median()
```




    9.0




```python
sales['Unit_Cost'].plot(kind='box', vert=False, figsize=(14,6))
```




    <AxesSubplot:>




    
![png](output_10_1.png)
    



```python
sales['Unit_Cost'].plot(kind='density', figsize=(14,6))
```




    <AxesSubplot:ylabel='Density'>




    
![png](output_11_1.png)
    



```python
ax = sales['Unit_Cost'].plot(kind='density', figsize=(14,6)) # kde
ax.axvline(sales['Unit_Cost'].mean(), color='red')
ax.axvline(sales['Unit_Cost'].median(), color='green')
```




    <matplotlib.lines.Line2D at 0x2b905686070>




    
![png](output_12_1.png)
    



```python
ax = sales['Unit_Cost'].plot(kind='hist', figsize=(14,6))
ax.set_ylabel('Number of Sales')
ax.set_xlabel('dollars')
```




    Text(0.5, 0, 'dollars')




    
![png](output_13_1.png)
    


*Categorical analysis and visualization

**We'll analyze the Age_Group column:


```python
sales.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Day</th>
      <th>Month</th>
      <th>Year</th>
      <th>Customer_Age</th>
      <th>Age_Group</th>
      <th>Customer_Gender</th>
      <th>Country</th>
      <th>State</th>
      <th>Product_Category</th>
      <th>Sub_Category</th>
      <th>Product</th>
      <th>Order_Quantity</th>
      <th>Unit_Cost</th>
      <th>Unit_Price</th>
      <th>Profit</th>
      <th>Cost</th>
      <th>Revenue</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2013-11-26</td>
      <td>26</td>
      <td>November</td>
      <td>2013</td>
      <td>19</td>
      <td>Youth (&lt;25)</td>
      <td>M</td>
      <td>Canada</td>
      <td>British Columbia</td>
      <td>Accessories</td>
      <td>Bike Racks</td>
      <td>Hitch Rack - 4-Bike</td>
      <td>8</td>
      <td>45</td>
      <td>120</td>
      <td>590</td>
      <td>360</td>
      <td>950</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2015-11-26</td>
      <td>26</td>
      <td>November</td>
      <td>2015</td>
      <td>19</td>
      <td>Youth (&lt;25)</td>
      <td>M</td>
      <td>Canada</td>
      <td>British Columbia</td>
      <td>Accessories</td>
      <td>Bike Racks</td>
      <td>Hitch Rack - 4-Bike</td>
      <td>8</td>
      <td>45</td>
      <td>120</td>
      <td>590</td>
      <td>360</td>
      <td>950</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2014-03-23</td>
      <td>23</td>
      <td>March</td>
      <td>2014</td>
      <td>49</td>
      <td>Adults (35-64)</td>
      <td>M</td>
      <td>Australia</td>
      <td>New South Wales</td>
      <td>Accessories</td>
      <td>Bike Racks</td>
      <td>Hitch Rack - 4-Bike</td>
      <td>23</td>
      <td>45</td>
      <td>120</td>
      <td>1366</td>
      <td>1035</td>
      <td>2401</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2016-03-23</td>
      <td>23</td>
      <td>March</td>
      <td>2016</td>
      <td>49</td>
      <td>Adults (35-64)</td>
      <td>M</td>
      <td>Australia</td>
      <td>New South Wales</td>
      <td>Accessories</td>
      <td>Bike Racks</td>
      <td>Hitch Rack - 4-Bike</td>
      <td>20</td>
      <td>45</td>
      <td>120</td>
      <td>1188</td>
      <td>900</td>
      <td>2088</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2014-05-15</td>
      <td>15</td>
      <td>May</td>
      <td>2014</td>
      <td>47</td>
      <td>Adults (35-64)</td>
      <td>F</td>
      <td>Australia</td>
      <td>New South Wales</td>
      <td>Accessories</td>
      <td>Bike Racks</td>
      <td>Hitch Rack - 4-Bike</td>
      <td>4</td>
      <td>45</td>
      <td>120</td>
      <td>238</td>
      <td>180</td>
      <td>418</td>
    </tr>
  </tbody>
</table>
</div>




```python
sales['Age_Group'].value_counts()
```




    Adults (35-64)          55824
    Young Adults (25-34)    38654
    Youth (<25)             17828
    Seniors (64+)             730
    Name: Age_Group, dtype: int64




```python
sales['Age_Group'].value_counts().plot(kind='pie', figsize=(6,6))
```




    <AxesSubplot:ylabel='Age_Group'>




    
![png](output_18_1.png)
    



```python
ax = sales['Age_Group'].value_counts().plot(kind='bar', figsize=(14,6))
ax.set_ylabel('Number of Sales')
```




    Text(0, 0.5, 'Number of Sales')




    
![png](output_19_1.png)
    


*Relationship between the columns?
**Can we find any significant relationship?


```python
corr = sales.corr()

corr
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Day</th>
      <th>Year</th>
      <th>Customer_Age</th>
      <th>Order_Quantity</th>
      <th>Unit_Cost</th>
      <th>Unit_Price</th>
      <th>Profit</th>
      <th>Cost</th>
      <th>Revenue</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Day</th>
      <td>1.000000</td>
      <td>-0.007635</td>
      <td>-0.014296</td>
      <td>-0.002412</td>
      <td>0.003133</td>
      <td>0.003207</td>
      <td>0.004623</td>
      <td>0.003329</td>
      <td>0.003853</td>
    </tr>
    <tr>
      <th>Year</th>
      <td>-0.007635</td>
      <td>1.000000</td>
      <td>0.040994</td>
      <td>0.123169</td>
      <td>-0.217575</td>
      <td>-0.213673</td>
      <td>-0.181525</td>
      <td>-0.215604</td>
      <td>-0.208673</td>
    </tr>
    <tr>
      <th>Customer_Age</th>
      <td>-0.014296</td>
      <td>0.040994</td>
      <td>1.000000</td>
      <td>0.026887</td>
      <td>-0.021374</td>
      <td>-0.020262</td>
      <td>0.004319</td>
      <td>-0.016013</td>
      <td>-0.009326</td>
    </tr>
    <tr>
      <th>Order_Quantity</th>
      <td>-0.002412</td>
      <td>0.123169</td>
      <td>0.026887</td>
      <td>1.000000</td>
      <td>-0.515835</td>
      <td>-0.515925</td>
      <td>-0.238863</td>
      <td>-0.340382</td>
      <td>-0.312895</td>
    </tr>
    <tr>
      <th>Unit_Cost</th>
      <td>0.003133</td>
      <td>-0.217575</td>
      <td>-0.021374</td>
      <td>-0.515835</td>
      <td>1.000000</td>
      <td>0.997894</td>
      <td>0.741020</td>
      <td>0.829869</td>
      <td>0.817865</td>
    </tr>
    <tr>
      <th>Unit_Price</th>
      <td>0.003207</td>
      <td>-0.213673</td>
      <td>-0.020262</td>
      <td>-0.515925</td>
      <td>0.997894</td>
      <td>1.000000</td>
      <td>0.749870</td>
      <td>0.826301</td>
      <td>0.818522</td>
    </tr>
    <tr>
      <th>Profit</th>
      <td>0.004623</td>
      <td>-0.181525</td>
      <td>0.004319</td>
      <td>-0.238863</td>
      <td>0.741020</td>
      <td>0.749870</td>
      <td>1.000000</td>
      <td>0.902233</td>
      <td>0.956572</td>
    </tr>
    <tr>
      <th>Cost</th>
      <td>0.003329</td>
      <td>-0.215604</td>
      <td>-0.016013</td>
      <td>-0.340382</td>
      <td>0.829869</td>
      <td>0.826301</td>
      <td>0.902233</td>
      <td>1.000000</td>
      <td>0.988758</td>
    </tr>
    <tr>
      <th>Revenue</th>
      <td>0.003853</td>
      <td>-0.208673</td>
      <td>-0.009326</td>
      <td>-0.312895</td>
      <td>0.817865</td>
      <td>0.818522</td>
      <td>0.956572</td>
      <td>0.988758</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
fig = plt.figure(figsize=(8,8))
plt.matshow(corr, cmap='RdBu', fignum=fig.number)
plt.xticks(range(len(corr.columns)), corr.columns, rotation='vertical');
plt.yticks(range(len(corr.columns)), corr.columns);
```


    
![png](output_22_0.png)
    



```python
sales.plot(kind='scatter', x='Customer_Age', y='Revenue', figsize=(6,6))
```




    <AxesSubplot:xlabel='Customer_Age', ylabel='Revenue'>




    
![png](output_23_1.png)
    



```python
sales.plot(kind='scatter', x='Revenue', y='Profit', figsize=(6,6))
```




    <AxesSubplot:xlabel='Revenue', ylabel='Profit'>




    
![png](output_24_1.png)
    



```python
ax = sales[['Profit', 'Age_Group']].boxplot(by='Age_Group', figsize=(10,6))
ax.set_ylabel('Profit')
```




    Text(0, 0.5, 'Profit')




    
![png](output_25_1.png)
    



```python
boxplot_cols = ['Year', 'Customer_Age', 'Order_Quantity', 'Unit_Cost', 'Unit_Price', 'Profit']

sales[boxplot_cols].plot(kind='box', subplots=True, layout=(2,3), figsize=(14,8))
```




    Year                 AxesSubplot(0.125,0.536818;0.227941x0.343182)
    Customer_Age      AxesSubplot(0.398529,0.536818;0.227941x0.343182)
    Order_Quantity    AxesSubplot(0.672059,0.536818;0.227941x0.343182)
    Unit_Cost               AxesSubplot(0.125,0.125;0.227941x0.343182)
    Unit_Price           AxesSubplot(0.398529,0.125;0.227941x0.343182)
    Profit               AxesSubplot(0.672059,0.125;0.227941x0.343182)
    dtype: object




    
![png](output_26_1.png)
    


*Column wrangling


**We can also create new columns or modify existing ones.

***Add and calculate a new Revenue_per_Age column


```python
sales['Revenue_per_Age'] = sales['Revenue'] / sales['Customer_Age']

sales['Revenue_per_Age'].head()
```




    0    50.000000
    1    50.000000
    2    49.000000
    3    42.612245
    4     8.893617
    Name: Revenue_per_Age, dtype: float64




```python
sales['Revenue_per_Age'].plot(kind='density', figsize=(14,6))
```




    <AxesSubplot:ylabel='Density'>




    
![png](output_31_1.png)
    



```python
sales['Revenue_per_Age'].plot(kind='hist', figsize=(14,6))
```




    <AxesSubplot:ylabel='Frequency'>




    
![png](output_32_1.png)
    


*Add and calculate a new Calculated_Cost column


```python
sales['Calculated_Cost'] = sales['Order_Quantity'] * sales['Unit_Cost']

sales['Calculated_Cost'].head()
```




    0     360
    1     360
    2    1035
    3     900
    4     180
    Name: Calculated_Cost, dtype: int64




```python
(sales['Calculated_Cost'] != sales['Cost']).sum()
```




    0




```python
sales.plot(kind='scatter', x='Calculated_Cost', y='Profit', figsize=(6,6))
```




    <AxesSubplot:xlabel='Calculated_Cost', ylabel='Profit'>




    
![png](output_36_1.png)
    


*Add and calculate a new Calculated_Revenue column


```python
sales['Calculated_Revenue'] = sales['Cost'] + sales['Profit']

sales['Calculated_Revenue'].head()
```




    0     950
    1     950
    2    2401
    3    2088
    4     418
    Name: Calculated_Revenue, dtype: int64




```python
(sales['Calculated_Revenue'] != sales['Revenue']).sum()
```




    0




```python
sales.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Day</th>
      <th>Month</th>
      <th>Year</th>
      <th>Customer_Age</th>
      <th>Age_Group</th>
      <th>Customer_Gender</th>
      <th>Country</th>
      <th>State</th>
      <th>Product_Category</th>
      <th>...</th>
      <th>Product</th>
      <th>Order_Quantity</th>
      <th>Unit_Cost</th>
      <th>Unit_Price</th>
      <th>Profit</th>
      <th>Cost</th>
      <th>Revenue</th>
      <th>Revenue_per_Age</th>
      <th>Calculated_Cost</th>
      <th>Calculated_Revenue</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2013-11-26</td>
      <td>26</td>
      <td>November</td>
      <td>2013</td>
      <td>19</td>
      <td>Youth (&lt;25)</td>
      <td>M</td>
      <td>Canada</td>
      <td>British Columbia</td>
      <td>Accessories</td>
      <td>...</td>
      <td>Hitch Rack - 4-Bike</td>
      <td>8</td>
      <td>45</td>
      <td>120</td>
      <td>590</td>
      <td>360</td>
      <td>950</td>
      <td>50.000000</td>
      <td>360</td>
      <td>950</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2015-11-26</td>
      <td>26</td>
      <td>November</td>
      <td>2015</td>
      <td>19</td>
      <td>Youth (&lt;25)</td>
      <td>M</td>
      <td>Canada</td>
      <td>British Columbia</td>
      <td>Accessories</td>
      <td>...</td>
      <td>Hitch Rack - 4-Bike</td>
      <td>8</td>
      <td>45</td>
      <td>120</td>
      <td>590</td>
      <td>360</td>
      <td>950</td>
      <td>50.000000</td>
      <td>360</td>
      <td>950</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2014-03-23</td>
      <td>23</td>
      <td>March</td>
      <td>2014</td>
      <td>49</td>
      <td>Adults (35-64)</td>
      <td>M</td>
      <td>Australia</td>
      <td>New South Wales</td>
      <td>Accessories</td>
      <td>...</td>
      <td>Hitch Rack - 4-Bike</td>
      <td>23</td>
      <td>45</td>
      <td>120</td>
      <td>1366</td>
      <td>1035</td>
      <td>2401</td>
      <td>49.000000</td>
      <td>1035</td>
      <td>2401</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2016-03-23</td>
      <td>23</td>
      <td>March</td>
      <td>2016</td>
      <td>49</td>
      <td>Adults (35-64)</td>
      <td>M</td>
      <td>Australia</td>
      <td>New South Wales</td>
      <td>Accessories</td>
      <td>...</td>
      <td>Hitch Rack - 4-Bike</td>
      <td>20</td>
      <td>45</td>
      <td>120</td>
      <td>1188</td>
      <td>900</td>
      <td>2088</td>
      <td>42.612245</td>
      <td>900</td>
      <td>2088</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2014-05-15</td>
      <td>15</td>
      <td>May</td>
      <td>2014</td>
      <td>47</td>
      <td>Adults (35-64)</td>
      <td>F</td>
      <td>Australia</td>
      <td>New South Wales</td>
      <td>Accessories</td>
      <td>...</td>
      <td>Hitch Rack - 4-Bike</td>
      <td>4</td>
      <td>45</td>
      <td>120</td>
      <td>238</td>
      <td>180</td>
      <td>418</td>
      <td>8.893617</td>
      <td>180</td>
      <td>418</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 21 columns</p>
</div>




```python
sales['Revenue'].plot(kind='hist', bins=100, figsize=(14,6))
```




    <AxesSubplot:ylabel='Frequency'>




    
![png](output_41_1.png)
    


*Modify all Unit_Price values adding 3% tax to them


```python
sales['Unit_Price'].head()
```




    0    120
    1    120
    2    120
    3    120
    4    120
    Name: Unit_Price, dtype: int64




```python
sales['Unit_Price'] *= 1.03
```


```python
sales['Unit_Price'].head()
```




    0    123.6
    1    123.6
    2    123.6
    3    123.6
    4    123.6
    Name: Unit_Price, dtype: float64



*Selection & Indexing:

 **Get all the sales made in the state of Kentucky


```python
sales.loc[sales['State'] == 'Kentucky']
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Day</th>
      <th>Month</th>
      <th>Year</th>
      <th>Customer_Age</th>
      <th>Age_Group</th>
      <th>Customer_Gender</th>
      <th>Country</th>
      <th>State</th>
      <th>Product_Category</th>
      <th>...</th>
      <th>Product</th>
      <th>Order_Quantity</th>
      <th>Unit_Cost</th>
      <th>Unit_Price</th>
      <th>Profit</th>
      <th>Cost</th>
      <th>Revenue</th>
      <th>Revenue_per_Age</th>
      <th>Calculated_Cost</th>
      <th>Calculated_Revenue</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>156</th>
      <td>2013-11-04</td>
      <td>4</td>
      <td>November</td>
      <td>2013</td>
      <td>40</td>
      <td>Adults (35-64)</td>
      <td>M</td>
      <td>United States</td>
      <td>Kentucky</td>
      <td>Accessories</td>
      <td>...</td>
      <td>Hitch Rack - 4-Bike</td>
      <td>1</td>
      <td>45</td>
      <td>123.60</td>
      <td>63</td>
      <td>45</td>
      <td>108</td>
      <td>2.700</td>
      <td>45</td>
      <td>108</td>
    </tr>
    <tr>
      <th>157</th>
      <td>2015-11-04</td>
      <td>4</td>
      <td>November</td>
      <td>2015</td>
      <td>40</td>
      <td>Adults (35-64)</td>
      <td>M</td>
      <td>United States</td>
      <td>Kentucky</td>
      <td>Accessories</td>
      <td>...</td>
      <td>Hitch Rack - 4-Bike</td>
      <td>1</td>
      <td>45</td>
      <td>123.60</td>
      <td>63</td>
      <td>45</td>
      <td>108</td>
      <td>2.700</td>
      <td>45</td>
      <td>108</td>
    </tr>
    <tr>
      <th>23826</th>
      <td>2014-04-16</td>
      <td>16</td>
      <td>April</td>
      <td>2014</td>
      <td>40</td>
      <td>Adults (35-64)</td>
      <td>M</td>
      <td>United States</td>
      <td>Kentucky</td>
      <td>Accessories</td>
      <td>...</td>
      <td>Fender Set - Mountain</td>
      <td>12</td>
      <td>8</td>
      <td>22.66</td>
      <td>142</td>
      <td>96</td>
      <td>238</td>
      <td>5.950</td>
      <td>96</td>
      <td>238</td>
    </tr>
    <tr>
      <th>23827</th>
      <td>2016-04-16</td>
      <td>16</td>
      <td>April</td>
      <td>2016</td>
      <td>40</td>
      <td>Adults (35-64)</td>
      <td>M</td>
      <td>United States</td>
      <td>Kentucky</td>
      <td>Accessories</td>
      <td>...</td>
      <td>Fender Set - Mountain</td>
      <td>14</td>
      <td>8</td>
      <td>22.66</td>
      <td>165</td>
      <td>112</td>
      <td>277</td>
      <td>6.925</td>
      <td>112</td>
      <td>277</td>
    </tr>
    <tr>
      <th>31446</th>
      <td>2014-04-16</td>
      <td>16</td>
      <td>April</td>
      <td>2014</td>
      <td>40</td>
      <td>Adults (35-64)</td>
      <td>M</td>
      <td>United States</td>
      <td>Kentucky</td>
      <td>Accessories</td>
      <td>...</td>
      <td>Sport-100 Helmet, Blue</td>
      <td>29</td>
      <td>13</td>
      <td>36.05</td>
      <td>537</td>
      <td>377</td>
      <td>914</td>
      <td>22.850</td>
      <td>377</td>
      <td>914</td>
    </tr>
    <tr>
      <th>31447</th>
      <td>2016-04-16</td>
      <td>16</td>
      <td>April</td>
      <td>2016</td>
      <td>40</td>
      <td>Adults (35-64)</td>
      <td>M</td>
      <td>United States</td>
      <td>Kentucky</td>
      <td>Accessories</td>
      <td>...</td>
      <td>Sport-100 Helmet, Blue</td>
      <td>31</td>
      <td>13</td>
      <td>36.05</td>
      <td>574</td>
      <td>403</td>
      <td>977</td>
      <td>24.425</td>
      <td>403</td>
      <td>977</td>
    </tr>
    <tr>
      <th>79670</th>
      <td>2014-04-16</td>
      <td>16</td>
      <td>April</td>
      <td>2014</td>
      <td>40</td>
      <td>Adults (35-64)</td>
      <td>M</td>
      <td>United States</td>
      <td>Kentucky</td>
      <td>Accessories</td>
      <td>...</td>
      <td>ML Mountain Tire</td>
      <td>2</td>
      <td>11</td>
      <td>30.90</td>
      <td>32</td>
      <td>22</td>
      <td>54</td>
      <td>1.350</td>
      <td>22</td>
      <td>54</td>
    </tr>
    <tr>
      <th>79671</th>
      <td>2014-04-16</td>
      <td>16</td>
      <td>April</td>
      <td>2014</td>
      <td>40</td>
      <td>Adults (35-64)</td>
      <td>M</td>
      <td>United States</td>
      <td>Kentucky</td>
      <td>Accessories</td>
      <td>...</td>
      <td>ML Mountain Tire</td>
      <td>21</td>
      <td>11</td>
      <td>30.90</td>
      <td>336</td>
      <td>231</td>
      <td>567</td>
      <td>14.175</td>
      <td>231</td>
      <td>567</td>
    </tr>
    <tr>
      <th>79672</th>
      <td>2016-04-16</td>
      <td>16</td>
      <td>April</td>
      <td>2016</td>
      <td>40</td>
      <td>Adults (35-64)</td>
      <td>M</td>
      <td>United States</td>
      <td>Kentucky</td>
      <td>Accessories</td>
      <td>...</td>
      <td>ML Mountain Tire</td>
      <td>1</td>
      <td>11</td>
      <td>30.90</td>
      <td>16</td>
      <td>11</td>
      <td>27</td>
      <td>0.675</td>
      <td>11</td>
      <td>27</td>
    </tr>
    <tr>
      <th>79673</th>
      <td>2016-04-16</td>
      <td>16</td>
      <td>April</td>
      <td>2016</td>
      <td>40</td>
      <td>Adults (35-64)</td>
      <td>M</td>
      <td>United States</td>
      <td>Kentucky</td>
      <td>Accessories</td>
      <td>...</td>
      <td>ML Mountain Tire</td>
      <td>18</td>
      <td>11</td>
      <td>30.90</td>
      <td>288</td>
      <td>198</td>
      <td>486</td>
      <td>12.150</td>
      <td>198</td>
      <td>486</td>
    </tr>
  </tbody>
</table>
<p>10 rows × 21 columns</p>
</div>



*Get the mean revenue of the Adults (35-64) sales group


```python
sales.loc[sales['Age_Group'] == 'Adults (35-64)', 'Revenue'].mean()
```




    762.8287654055604



How many records belong to Age Group Youth (<25) or Adults (35-64)?


```python
sales.loc[(sales['Age_Group'] == 'Youth (<25)') | (sales['Age_Group'] == 'Adults (35-64)')].shape[0]
```




    73652



*Get the mean revenue of the sales group Adults (35-64) in United States


```python
sales.loc[(sales['Age_Group'] == 'Adults (35-64)') & (sales['Country'] == 'United States'), 'Revenue'].mean()
```




    726.7260473588342



* Increase the revenue by 10% to every sale made in France


```python
sales.loc[sales['Country'] == 'France', 'Revenue'].head()
```




    50     787
    51     787
    52    2957
    53    2851
    60     626
    Name: Revenue, dtype: int64




```python
sales.loc[sales['Country'] == 'France', 'Revenue'] *= 1.1
```


```python
sales.loc[sales['Country'] == 'France', 'Revenue'].head()
```




    50     865.7
    51     865.7
    52    3252.7
    53    3136.1
    60     688.6
    Name: Revenue, dtype: float64




```python

```
