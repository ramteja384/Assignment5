**Handling Missing Data with Pandas**


```python
import numpy as np
import pandas as pd
```

Pandas utility functions

Similarly to numpy, pandas also has a few utility functions to identify and detect null values:


```python
pd.isnull(np.nan)
```




    True




```python
pd.isnull(None)
```




    True




```python
pd.isna(None)
```




    True




```python
pd.notnull(None)
```




    False




```python
pd.notnull(np.nan)
```




    False




```python
pd.notna(np.nan)
```




    False




```python
pd.notnull(3)
```




    True



These functions also work with Series and DataFrames:


```python
pd.isnull(pd.Series([1, np.nan, 7]))
```




    0    False
    1     True
    2    False
    dtype: bool




```python
pd.notnull(pd.Series([1, np.nan, 7]))
```




    0     True
    1    False
    2     True
    dtype: bool




```python
pd.isnull(pd.DataFrame({
    'Column A': [1, np.nan, 7],
    'Column B': [np.nan, 2, 3],
    'Column C': [np.nan, 2, np.nan]
}))
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Column A</th>
      <th>Column B</th>
      <th>Column C</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>False</td>
      <td>True</td>
      <td>True</td>
    </tr>
    <tr>
      <th>1</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>False</td>
      <td>False</td>
      <td>True</td>
    </tr>
  </tbody>
</table>
</div>



**Pandas Operations with Missing Values**

Pandas manages missing values more gracefully than numpy. nans will no longer behave as "viruses", and operations will just ignore them completely:


```python
pd.Series([1, 2, np.nan]).count()
```




    2




```python
pd.Series([1, 2, np.nan]).sum()
```




    3.0




```python
pd.Series([2, 2, np.nan]).mean()
```




    2.0



**Filtering missing data**

As we saw with numpy, we could combine boolean selection + pd.isnull to filter out those nans and null values:


```python
s = pd.Series([1, 2, 3, np.nan, np.nan, 4])
```


```python
pd.notnull(s)
```




    0     True
    1     True
    2     True
    3    False
    4    False
    5     True
    dtype: bool




```python
pd.isnull(s)
```




    0    False
    1    False
    2    False
    3     True
    4     True
    5    False
    dtype: bool




```python
pd.notnull(s).sum()
```




    4




```python
pd.isnull(s).sum()
```




    2




```python
s[pd.notnull(s)]
```




    0    1.0
    1    2.0
    2    3.0
    5    4.0
    dtype: float64




```python
s.isnull()
```




    0    False
    1    False
    2    False
    3     True
    4     True
    5    False
    dtype: bool




```python
s.notnull()
```




    0     True
    1     True
    2     True
    3    False
    4    False
    5     True
    dtype: bool




```python
s[s.notnull()]
```




    0    1.0
    1    2.0
    2    3.0
    5    4.0
    dtype: float64



**Dropping null values**

Boolean selection + notnull() seems a little bit verbose and repetitive. And as we said before: any repetitive task will probably have a better, more DRY way. In this case, we can use the dropna method:


```python
s
```




    0    1.0
    1    2.0
    2    3.0
    3    NaN
    4    NaN
    5    4.0
    dtype: float64




```python
s.dropna()
```




    0    1.0
    1    2.0
    2    3.0
    5    4.0
    dtype: float64



**Dropping null values on DataFrames**

You saw how simple it is to drop nas with a Series. But with DataFrames, there will be a few more things to consider, because you can't drop single values. You can only drop entire columns or rows. Let's start with a sample DataFrame:


```python
df = pd.DataFrame({
    'Column A': [1, np.nan, 30, np.nan],
    'Column B': [2, 8, 31, np.nan],
    'Column C': [np.nan, 9, 32, 100],
    'Column D': [5, 8, 34, 110],
})
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Column A</th>
      <th>Column B</th>
      <th>Column C</th>
      <th>Column D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>2.0</td>
      <td>NaN</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
      <td>8.0</td>
      <td>9.0</td>
      <td>8</td>
    </tr>
    <tr>
      <th>2</th>
      <td>30.0</td>
      <td>31.0</td>
      <td>32.0</td>
      <td>34</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>100.0</td>
      <td>110</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.shape
```




    (4, 4)




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 4 entries, 0 to 3
    Data columns (total 4 columns):
     #   Column    Non-Null Count  Dtype  
    ---  ------    --------------  -----  
     0   Column A  2 non-null      float64
     1   Column B  3 non-null      float64
     2   Column C  3 non-null      float64
     3   Column D  4 non-null      int64  
    dtypes: float64(3), int64(1)
    memory usage: 256.0 bytes
    


```python
df.isnull()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Column A</th>
      <th>Column B</th>
      <th>Column C</th>
      <th>Column D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.isnull().sum()
```




    Column A    2
    Column B    1
    Column C    1
    Column D    0
    dtype: int64



The default dropna behavior will drop all the rows in which any null value is present:


```python
df.dropna()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Column A</th>
      <th>Column B</th>
      <th>Column C</th>
      <th>Column D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2</th>
      <td>30.0</td>
      <td>31.0</td>
      <td>32.0</td>
      <td>34</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.dropna(axis=1)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Column D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>8</td>
    </tr>
    <tr>
      <th>2</th>
      <td>34</td>
    </tr>
    <tr>
      <th>3</th>
      <td>110</td>
    </tr>
  </tbody>
</table>
</div>




```python

```

In this case, any row or column that contains at least one null value will be dropped. Which can be, depending on the case, too extreme. You can control this behavior with the how parameter. Can be either 'any' or 'all':


```python
df2 = pd.DataFrame({
    'Column A': [1, np.nan, 30],
    'Column B': [2, np.nan, 31],
    'Column C': [np.nan, np.nan, 100]
})

```


```python
df2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Column A</th>
      <th>Column B</th>
      <th>Column C</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>2.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>30.0</td>
      <td>31.0</td>
      <td>100.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.dropna(how='all')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Column A</th>
      <th>Column B</th>
      <th>Column C</th>
      <th>Column D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>2.0</td>
      <td>NaN</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
      <td>8.0</td>
      <td>9.0</td>
      <td>8</td>
    </tr>
    <tr>
      <th>2</th>
      <td>30.0</td>
      <td>31.0</td>
      <td>32.0</td>
      <td>34</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>100.0</td>
      <td>110</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.dropna(how='any') 
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Column A</th>
      <th>Column B</th>
      <th>Column C</th>
      <th>Column D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2</th>
      <td>30.0</td>
      <td>31.0</td>
      <td>32.0</td>
      <td>34</td>
    </tr>
  </tbody>
</table>
</div>



You can also use the thresh parameter to indicate a threshold (a minimum number) of non-null values for the row/column to be kept:


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Column A</th>
      <th>Column B</th>
      <th>Column C</th>
      <th>Column D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>2.0</td>
      <td>NaN</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
      <td>8.0</td>
      <td>9.0</td>
      <td>8</td>
    </tr>
    <tr>
      <th>2</th>
      <td>30.0</td>
      <td>31.0</td>
      <td>32.0</td>
      <td>34</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>100.0</td>
      <td>110</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.dropna(thresh=3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Column A</th>
      <th>Column B</th>
      <th>Column C</th>
      <th>Column D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>2.0</td>
      <td>NaN</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
      <td>8.0</td>
      <td>9.0</td>
      <td>8</td>
    </tr>
    <tr>
      <th>2</th>
      <td>30.0</td>
      <td>31.0</td>
      <td>32.0</td>
      <td>34</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.dropna(thresh=3, axis='columns')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Column B</th>
      <th>Column C</th>
      <th>Column D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2.0</td>
      <td>NaN</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>8.0</td>
      <td>9.0</td>
      <td>8</td>
    </tr>
    <tr>
      <th>2</th>
      <td>31.0</td>
      <td>32.0</td>
      <td>34</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>100.0</td>
      <td>110</td>
    </tr>
  </tbody>
</table>
</div>



**Filling null values**

Sometimes instead than dropping the null values, we might need to replace them with some other value. This highly depends on your context and the dataset you're currently working. Sometimes a nan can be replaced with a 0, sometimes it can be replaced with the mean of the sample, and some other times you can take the closest value. Again, it depends on the context. We'll show you the different methods and mechanisms and you can then apply them to your own problem.


```python
s
```




    0    1.0
    1    2.0
    2    3.0
    3    NaN
    4    NaN
    5    4.0
    dtype: float64



**Filling nulls with a arbitrary value**


```python
s.fillna(0)
```




    0    1.0
    1    2.0
    2    3.0
    3    0.0
    4    0.0
    5    4.0
    dtype: float64




```python
s.fillna(s.mean())
```




    0    1.0
    1    2.0
    2    3.0
    3    2.5
    4    2.5
    5    4.0
    dtype: float64




```python
s
```




    0    1.0
    1    2.0
    2    3.0
    3    NaN
    4    NaN
    5    4.0
    dtype: float64



**Filling nulls with contiguous (close) values**

The method argument is used to fill null values with other values close to that null one:


```python
s.fillna(method='ffill')
```




    0    1.0
    1    2.0
    2    3.0
    3    3.0
    4    3.0
    5    4.0
    dtype: float64




```python
s.fillna(method='bfill')
```




    0    1.0
    1    2.0
    2    3.0
    3    4.0
    4    4.0
    5    4.0
    dtype: float64



This can still leave null values at the extremes of the Series/DataFrame:


```python
pd.Series([np.nan, 3, np.nan, 9]).fillna(method='ffill')
```




    0    NaN
    1    3.0
    2    3.0
    3    9.0
    dtype: float64




```python
pd.Series([1, np.nan, 3, np.nan, np.nan]).fillna(method='bfill')
```




    0    1.0
    1    3.0
    2    3.0
    3    NaN
    4    NaN
    dtype: float64



**Filling null values on DataFrames**
The fillna method also works on DataFrames, and it works similarly. The main differences are that you can specify the axis (as usual, rows or columns) to use to fill the values (specially for methods) and that you have more control on the values passed:


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Column A</th>
      <th>Column B</th>
      <th>Column C</th>
      <th>Column D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>2.0</td>
      <td>NaN</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
      <td>8.0</td>
      <td>9.0</td>
      <td>8</td>
    </tr>
    <tr>
      <th>2</th>
      <td>30.0</td>
      <td>31.0</td>
      <td>32.0</td>
      <td>34</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>100.0</td>
      <td>110</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.fillna({'Column A': 0, 'Column B': 99, 'Column C': df['Column C'].mean()})
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Column A</th>
      <th>Column B</th>
      <th>Column C</th>
      <th>Column D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>2.0</td>
      <td>47.0</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.0</td>
      <td>8.0</td>
      <td>9.0</td>
      <td>8</td>
    </tr>
    <tr>
      <th>2</th>
      <td>30.0</td>
      <td>31.0</td>
      <td>32.0</td>
      <td>34</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.0</td>
      <td>99.0</td>
      <td>100.0</td>
      <td>110</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.fillna(method='ffill', axis=0)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Column A</th>
      <th>Column B</th>
      <th>Column C</th>
      <th>Column D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>2.0</td>
      <td>NaN</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1.0</td>
      <td>8.0</td>
      <td>9.0</td>
      <td>8</td>
    </tr>
    <tr>
      <th>2</th>
      <td>30.0</td>
      <td>31.0</td>
      <td>32.0</td>
      <td>34</td>
    </tr>
    <tr>
      <th>3</th>
      <td>30.0</td>
      <td>31.0</td>
      <td>100.0</td>
      <td>110</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.fillna(method='ffill', axis=1)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Column A</th>
      <th>Column B</th>
      <th>Column C</th>
      <th>Column D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
      <td>8.0</td>
      <td>9.0</td>
      <td>8.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>30.0</td>
      <td>31.0</td>
      <td>32.0</td>
      <td>34.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>100.0</td>
      <td>110.0</td>
    </tr>
  </tbody>
</table>
</div>




```python

```

**Cleaning not-null values**

After dealing with many datasets I can tell you that "missing data" is not such a big deal. The best thing that can happen is to clearly see values like np.nan. The only thing you need to do is just use methods like isnull and fillna/dropna and pandas will take care of the rest.

But sometimes, you can have invalid values that are not just "missing data" (None, or nan). For example:


```python
df = pd.DataFrame({
    'Sex': ['M', 'F', 'F', 'D', '?'],
    'Age': [29, 30, 24, 290, 25],
})
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Sex</th>
      <th>Age</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>M</td>
      <td>29</td>
    </tr>
    <tr>
      <th>1</th>
      <td>F</td>
      <td>30</td>
    </tr>
    <tr>
      <th>2</th>
      <td>F</td>
      <td>24</td>
    </tr>
    <tr>
      <th>3</th>
      <td>D</td>
      <td>290</td>
    </tr>
    <tr>
      <th>4</th>
      <td>?</td>
      <td>25</td>
    </tr>
  </tbody>
</table>
</div>



The previous DataFrame doesn't have any "missing value", but clearly has invalid data. 290 doesn't seem like a valid age, and D and ? don't correspond with any known sex category. How can you clean these not-missing, but clearly invalid values then?

**Finding Unique Values**
The first step to clean invalid values is to notice them, then identify them and finally handle them appropriately (remove them, replace them, etc). Usually, for a "categorical" type of field (like Sex, which only takes values of a discrete set ('M', 'F')), we start by analyzing the variety of values present. For that, we use the unique() method:


```python
df['Sex'].unique()
```




    array(['M', 'F', 'D', '?'], dtype=object)




```python
df['Sex'].value_counts()
```




    F    2
    ?    1
    D    1
    M    1
    Name: Sex, dtype: int64



Clearly if you see values like 'D' or '?', it'll immediately raise your attention. Now, what to do with them? Let's say you picked up the phone, called the survey company and they told you that 'D' was a typo and it should actually be F. You can use the replace function to replace these values:


```python
df['Sex'].replace('D', 'F')
```




    0    M
    1    F
    2    F
    3    F
    4    ?
    Name: Sex, dtype: object




```python
df['Sex'].replace({'D': 'F', 'N': 'M'})
```




    0    M
    1    F
    2    F
    3    F
    4    ?
    Name: Sex, dtype: object



If you have many columns to replace, you could apply it at "DataFrame level":


```python
df.replace({
    'Sex': {
        'D': 'F',
        'N': 'M'
    },
    'Age': {
        290: 29
    }
})
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Sex</th>
      <th>Age</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>M</td>
      <td>29</td>
    </tr>
    <tr>
      <th>1</th>
      <td>F</td>
      <td>30</td>
    </tr>
    <tr>
      <th>2</th>
      <td>F</td>
      <td>24</td>
    </tr>
    <tr>
      <th>3</th>
      <td>F</td>
      <td>29</td>
    </tr>
    <tr>
      <th>4</th>
      <td>?</td>
      <td>25</td>
    </tr>
  </tbody>
</table>
</div>



In the previous example, I explicitly replaced 290 with 29 (assuming it was just an extra 0 entered at data-entry phase). But what if you'd like to remove all the extra 0s from the ages columns? (example, 150 > 15, 490 > 49).

The first step would be to just set the limit of the "not possible" age. Is it 100? 120? Let's say that anything above 100 isn't credible for our dataset. We can then combine boolean selection with the operation:


```python
df[df['Age'] > 100]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Sex</th>
      <th>Age</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3</th>
      <td>D</td>
      <td>290</td>
    </tr>
  </tbody>
</table>
</div>



And we can now just divide by 10:


```python
df.loc[df['Age'] > 100, 'Age'] = df.loc[df['Age'] > 100, 'Age'] / 10
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Sex</th>
      <th>Age</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>M</td>
      <td>29.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>F</td>
      <td>30.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>F</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>D</td>
      <td>29.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>?</td>
      <td>25.0</td>
    </tr>
  </tbody>
</table>
</div>



**Duplicates**

Checking duplicate values is extremely simple. It'll behave differently between Series and DataFrames. Let's start with Series. As an example, let's say we're throwing a fancy party and we're inviting Ambassadors from Europe. But can only invite one ambassador per country. This is our original list, and as you can see, both the UK and Germany have duplicated ambassadors:


```python
ambassadors = pd.Series([
    'France',
    'United Kingdom',
    'United Kingdom',
    'Italy',
    'Germany',
    'Germany',
    'Germany',
], index=[
    'Gérard Araud',
    'Kim Darroch',
    'Peter Westmacott',
    'Armando Varricchio',
    'Peter Wittig',
    'Peter Ammon',
    'Klaus Scharioth '
])
ambassadors
```




    Gérard Araud                  France
    Kim Darroch           United Kingdom
    Peter Westmacott      United Kingdom
    Armando Varricchio             Italy
    Peter Wittig                 Germany
    Peter Ammon                  Germany
    Klaus Scharioth              Germany
    dtype: object



The two most important methods to deal with duplicates are duplicated (that will tell you which values are duplicates) and drop_duplicates (which will just get rid of duplicates):


```python
ambassadors.duplicated()
```




    Gérard Araud          False
    Kim Darroch           False
    Peter Westmacott       True
    Armando Varricchio    False
    Peter Wittig          False
    Peter Ammon            True
    Klaus Scharioth        True
    dtype: bool



In this case duplicated didn't consider 'Kim Darroch', the first instance of the United Kingdom or 'Peter Wittig' as duplicates. That's because, by default, it'll consider the first occurrence of the value as not-duplicate. You can change this behavior with the keep parameter:


```python
ambassadors.duplicated(keep='last')
```




    Gérard Araud          False
    Kim Darroch            True
    Peter Westmacott      False
    Armando Varricchio    False
    Peter Wittig           True
    Peter Ammon            True
    Klaus Scharioth       False
    dtype: bool



In this case, the result is "flipped", 'Kim Darroch' and 'Peter Wittig' (the first ambassadors of their countries) are considered duplicates, but 'Peter Westmacott' and 'Klaus Scharioth' are not duplicates. You can also choose to mark all of them as duplicates with keep=False:


```python
ambassadors.duplicated(keep=False)
```




    Gérard Araud          False
    Kim Darroch            True
    Peter Westmacott       True
    Armando Varricchio    False
    Peter Wittig           True
    Peter Ammon            True
    Klaus Scharioth        True
    dtype: bool



A similar method is drop_duplicates, which just excludes the duplicated values and also accepts the keep parameter:


```python

```


```python
ambassadors.drop_duplicates()
```




    Gérard Araud                  France
    Kim Darroch           United Kingdom
    Armando Varricchio             Italy
    Peter Wittig                 Germany
    dtype: object




```python
ambassadors.drop_duplicates(keep='last')
```




    Gérard Araud                  France
    Peter Westmacott      United Kingdom
    Armando Varricchio             Italy
    Klaus Scharioth              Germany
    dtype: object




```python
ambassadors.drop_duplicates(keep=False)
```




    Gérard Araud          France
    Armando Varricchio     Italy
    dtype: object



**Duplicates in DataFrames**

Conceptually speaking, duplicates in a DataFrame happen at "row" level. Two rows with exactly the same values are considered to be duplicates:


```python
players = pd.DataFrame({
    'Name': [
        'Kobe Bryant',
        'LeBron James',
        'Kobe Bryant',
        'Carmelo Anthony',
        'Kobe Bryant',
    ],
    'Pos': [
        'SG',
        'SF',
        'SG',
        'SF',
        'SF'
    ]
})
players
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Pos</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kobe Bryant</td>
      <td>SG</td>
    </tr>
    <tr>
      <th>1</th>
      <td>LeBron James</td>
      <td>SF</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Kobe Bryant</td>
      <td>SG</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Carmelo Anthony</td>
      <td>SF</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Kobe Bryant</td>
      <td>SF</td>
    </tr>
  </tbody>
</table>
</div>



In the previous DataFrame, we clearly see that Kobe is duplicated; but he appears with two different positions. What does duplicated say?


```python
players.duplicated()
```




    0    False
    1    False
    2     True
    3    False
    4    False
    dtype: bool



Again, conceptually, "duplicated" means "all the column values should be duplicates". We can customize this with the subset parameter:


```python
players.duplicated(subset=['Name'])
```




    0    False
    1    False
    2     True
    3    False
    4     True
    dtype: bool



And the same rules of keep still apply:


```python
players.duplicated(subset=['Name'], keep='last')
```




    0     True
    1    False
    2     True
    3    False
    4    False
    dtype: bool



drop_duplicates takes the same parameters:


```python
players.drop_duplicates()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Pos</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kobe Bryant</td>
      <td>SG</td>
    </tr>
    <tr>
      <th>1</th>
      <td>LeBron James</td>
      <td>SF</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Carmelo Anthony</td>
      <td>SF</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Kobe Bryant</td>
      <td>SF</td>
    </tr>
  </tbody>
</table>
</div>




```python
players.drop_duplicates(subset=['Name'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Pos</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kobe Bryant</td>
      <td>SG</td>
    </tr>
    <tr>
      <th>1</th>
      <td>LeBron James</td>
      <td>SF</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Carmelo Anthony</td>
      <td>SF</td>
    </tr>
  </tbody>
</table>
</div>




```python
players.drop_duplicates(subset=['Name'], keep='last')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Pos</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>LeBron James</td>
      <td>SF</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Carmelo Anthony</td>
      <td>SF</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Kobe Bryant</td>
      <td>SF</td>
    </tr>
  </tbody>
</table>
</div>



**Text Handling**

Cleaning text values can be incredibly hard. Invalid text values involves, 99% of the time, mistyping, which is completely unpredictable and doesn't follow any pattern. Thankfully, it's not so common these days, where data-entry tasks have been replaced by machines. Still, let's explore the most common cases:

**Splitting Columns**

The result of a survey is loaded and this is what you get:


```python
df = pd.DataFrame({
    'Data': [
        '1987_M_US _1',
        '1990?_M_UK_1',
        '1992_F_US_2',
        '1970?_M_   IT_1',
        '1985_F_I  T_2'
]})
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Data</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1987_M_US _1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1990?_M_UK_1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1992_F_US_2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1970?_M_   IT_1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1985_F_I  T_2</td>
    </tr>
  </tbody>
</table>
</div>



You know that the single columns represent the values "year, Sex, Country and number of children", but it's all been grouped in the same column and separated by an underscore. Pandas has a convenient method named split that we can use in these situations:


```python
df['Data'].str.split('_')
```




    0       [1987, M, US , 1]
    1       [1990?, M, UK, 1]
    2        [1992, F, US, 2]
    3    [1970?, M,    IT, 1]
    4      [1985, F, I  T, 2]
    Name: Data, dtype: object




```python
df['Data'].str.split('_', expand=True)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1987</td>
      <td>M</td>
      <td>US</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1990?</td>
      <td>M</td>
      <td>UK</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1992</td>
      <td>F</td>
      <td>US</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1970?</td>
      <td>M</td>
      <td>IT</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1985</td>
      <td>F</td>
      <td>I  T</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
df = df['Data'].str.split('_', expand=True)
```


```python
df.columns = ['Year', 'Sex', 'Country', 'No Children']
```

You can also check which columns contain a given value with the contains method:


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year</th>
      <th>Sex</th>
      <th>Country</th>
      <th>No Children</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1987</td>
      <td>M</td>
      <td>US</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1990?</td>
      <td>M</td>
      <td>UK</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1992</td>
      <td>F</td>
      <td>US</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1970?</td>
      <td>M</td>
      <td>IT</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1985</td>
      <td>F</td>
      <td>I  T</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
df['Year'].str.contains('\?')
```




    0    False
    1     True
    2    False
    3     True
    4    False
    Name: Year, dtype: bool



contains takes a regex/pattern as first value, so we need to escape the ? symbol as it has a special meaning for these patterns. Regular letters don't need escaping:


```python
df['Country'].str.contains('U')
```




    0     True
    1     True
    2     True
    3    False
    4    False
    Name: Country, dtype: bool



Removing blank spaces (like in 'US ' or 'I  T' can be achieved with strip (lstrip and rstrip also exist) or just replace:


```python
df['Country'].str.strip()
```




    0      US
    1      UK
    2      US
    3      IT
    4    I  T
    Name: Country, dtype: object




```python
df['Country'].str.replace(' ', '')
```




    0    US
    1    UK
    2    US
    3    IT
    4    IT
    Name: Country, dtype: object



As we said, replace and contains take regex patterns, which can make it easier to replace values in bulk:


```python
df['Year'].str.replace(r'(?P<year>\d{4})\?', lambda m: m.group('year'))
```




    0    1987
    1    1990
    2    1992
    3    1970
    4    1985
    Name: Year, dtype: object




```python

```

**More Visualizations**


```python
import matplotlib.pyplot as plt

%matplotlib inline
```

Global API
Matplotlib's default pyplot API has a global, MATLAB-style interface, as we've already seen:


```python
x = np.arange(-10, 11)
plt.figure(figsize=(12, 6))

plt.title('My Nice Plot')

plt.plot(x, x ** 2)
plt.plot(x, -1 * (x ** 2))
```




    [<matplotlib.lines.Line2D at 0x1c605a92700>]




    
![png](output_130_1.png)
    



```python
plt.figure(figsize=(12, 6))
plt.title('My Nice Plot')

plt.subplot(1, 2, 1)  # rows, columns, panel selected
plt.plot(x, x ** 2)
plt.plot([0, 0, 0], [-10, 0, 100])
plt.legend(['X^2', 'Vertical Line'])
plt.xlabel('X')
plt.ylabel('X Squared')

plt.subplot(1, 2, 2)
plt.plot(x, -1 * (x ** 2))
plt.plot([-10, 0, 10], [-50, -50, -50])
plt.legend(['-X^2', 'Horizontal Line'])

plt.xlabel('X')
plt.ylabel('X Squared')
```




    Text(0, 0.5, 'X Squared')




    
![png](output_131_1.png)
    


**OOP interface**


```python
fig, axes = plt.subplots(figsize=(12, 6))
```


    
![png](output_133_0.png)
    



```python
axes.plot(
    x, (x ** 2), color='red', linewidth=3,
    marker='o', markersize=8, label='X^2')

axes.plot(x, -1 * (x ** 2), 'b--', label='-X^2')

axes.set_xlabel('X')
axes.set_ylabel('X Squared')

axes.set_title("My Nice Plot")

axes.legend()

fig
```




    
![png](output_134_0.png)
    




```python
fig, axes = plt.subplots(figsize=(12, 6))

axes.plot(x, x + 0, linestyle='solid')
axes.plot(x, x + 1, linestyle='dashed')
axes.plot(x, x + 2, linestyle='dashdot')
axes.plot(x, x + 3, linestyle='dotted');

axes.set_title("My Nice Plot")
```




    Text(0.5, 1.0, 'My Nice Plot')




    
![png](output_135_1.png)
    



```python
fig, axes = plt.subplots(figsize=(12, 6))

axes.plot(x, x + 0, '-og', label="solid green")
axes.plot(x, x + 1, '--c', label="dashed cyan")
axes.plot(x, x + 2, '-.b', label="dashdot blue")
axes.plot(x, x + 3, ':r', label="dotted red")

axes.set_title("My Nice Plot")

axes.legend()
```




    <matplotlib.legend.Legend at 0x1c605f3cac0>




    
![png](output_136_1.png)
    


There are a lot of line and marker types.


```python
print('Markers: {}'.format([m for m in plt.Line2D.markers]))
```

    Markers: ['.', ',', 'o', 'v', '^', '<', '>', '1', '2', '3', '4', '8', 's', 'p', '*', 'h', 'H', '+', 'x', 'D', 'd', '|', '_', 'P', 'X', 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 'None', None, ' ', '']
    


```python
linestyles = ['_', '-', '--', ':']

print('Line styles: {}'.format(linestyles))
```

    Line styles: ['_', '-', '--', ':']
    

**Other types of plots**


Figures and subfigures

When we call the subplots() function we get a tuple containing a Figure and a axes element.


```python
plot_objects = plt.subplots()

fig, ax = plot_objects

ax.plot([1,2,3], [1,2,3])

plot_objects
```




    (<Figure size 432x288 with 1 Axes>, <AxesSubplot:>)




    
![png](output_141_1.png)
    


We can also define how many elements we want inside our figure. To do that we can set the nrows and ncols params.


```python
plot_objects = plt.subplots(nrows=2, ncols=2, figsize=(14, 6))

fig, ((ax1, ax2), (ax3, ax4)) = plot_objects

plot_objects
```




    (<Figure size 1008x432 with 4 Axes>,
     array([[<AxesSubplot:>, <AxesSubplot:>],
            [<AxesSubplot:>, <AxesSubplot:>]], dtype=object))




    
![png](output_143_1.png)
    



```python

```


```python
ax4.plot(np.random.randn(50), c='yellow')
ax1.plot(np.random.randn(50), c='red', linestyle='--')
ax2.plot(np.random.randn(50), c='green', linestyle=':')
ax3.plot(np.random.randn(50), c='blue', marker='o', linewidth=3.0)


fig
```




    
![png](output_145_0.png)
    



**The subplot2grid command**

There is another way to make subplots using a grid-like format:


```python
plt.figure(figsize=(14, 6))

ax1 = plt.subplot2grid((3,3), (0,0), colspan=3)
ax2 = plt.subplot2grid((3,3), (1,0), colspan=2)
ax3 = plt.subplot2grid((3,3), (1,2), rowspan=2)
ax4 = plt.subplot2grid((3,3), (2,0))
ax5 = plt.subplot2grid((3,3), (2,1))
```


    
![png](output_147_0.png)
    


**Scatter Plot**


```python
N = 50
x = np.random.rand(N)
y = np.random.rand(N)
colors = np.random.rand(N)
area = np.pi * (20 * np.random.rand(N))**2  # 0 to 15 point radii
plt.figure(figsize=(14, 6))

plt.scatter(x, y, s=area, c=colors, alpha=0.5, cmap='Spectral')
plt.colorbar()

plt.show()
```


    
![png](output_149_0.png)
    



```python
fig = plt.figure(figsize=(14, 6))

ax1 = fig.add_subplot(1,2,1)
plt.scatter(x, y, s=area, c=colors, alpha=0.5, cmap='Pastel1')
plt.colorbar()

ax2 = fig.add_subplot(1,2,2)
plt.scatter(x, y, s=area, c=colors, alpha=0.5, cmap='Pastel2')
plt.colorbar()

plt.show()
```


    
![png](output_150_0.png)
    


**Histograms**


```python
values = np.random.randn(1000)
plt.subplots(figsize=(12, 6))

plt.hist(values, bins=100, alpha=0.8,
          histtype='bar', color='steelblue',
          edgecolor='green')
plt.xlim(xmin=-5, xmax=5)

plt.show()
```


    
![png](output_152_0.png)
    


**KDE (kernel density estimation)**


```python
from scipy import stats

density = stats.kde.gaussian_kde(values)
density
```




    <scipy.stats.kde.gaussian_kde at 0x1c606043d90>




```python
plt.subplots(figsize=(12, 6))

values2 = np.linspace(min(values)-10, max(values)+10, 100)

plt.plot(values2, density(values2), color='#FF7F00')
plt.fill_between(values2, 0, density(values2), alpha=0.5, color='#FF7F00')
plt.xlim(xmin=-5, xmax=5)

plt.show()
```


    
![png](output_155_0.png)
    



```python

```

**Combine plots**


```python
plt.subplots(figsize=(12, 6))

plt.hist(values, bins=100, alpha=0.8, density=1,
          histtype='bar', color='steelblue',
          edgecolor='green')

plt.plot(values2, density(values2), color='#FF7F00', linewidth=3.0)
plt.xlim(xmin=-5, xmax=5)

plt.show()
```


    
![png](output_158_0.png)
    


**Bar plots**


```python
Y = np.random.rand(1, 5)[0]
Y2 = np.random.rand(1, 5)[0]
plt.figure(figsize=(12, 4))

barWidth = 0.5
plt.bar(np.arange(len(Y)), Y, width=barWidth, color='#00b894')

plt.show()
```


    
![png](output_160_0.png)
    


Also can be stacked bars, and add a legend to the plot:


```python
plt.figure(figsize=(12, 4))

barWidth = 0.5
plt.bar(np.arange(len(Y)), Y, width=barWidth, color='#00b894', label='Label Y')
plt.bar(np.arange(len(Y2)), Y2, width=barWidth, color='#e17055', bottom=Y, label='Label Y2')

plt.legend()
plt.show()
```


    
![png](output_162_0.png)
    


**Boxplots and outlier detection**


```python
values = np.concatenate([np.random.randn(10), np.array([10, 15, -10, -15])])
plt.figure(figsize=(12, 4))

plt.hist(values)
```




    (array([1., 1., 0., 0., 6., 4., 0., 0., 1., 1.]),
     array([-15., -12.,  -9.,  -6.,  -3.,   0.,   3.,   6.,   9.,  12.,  15.]),
     <BarContainer object of 10 artists>)




    
![png](output_164_1.png)
    



```python
plt.figure(figsize=(12, 4))

plt.boxplot(values)
```




    {'whiskers': [<matplotlib.lines.Line2D at 0x1c608bf7250>,
      <matplotlib.lines.Line2D at 0x1c608d99ac0>],
     'caps': [<matplotlib.lines.Line2D at 0x1c608d99f40>,
      <matplotlib.lines.Line2D at 0x1c608d991f0>],
     'boxes': [<matplotlib.lines.Line2D at 0x1c608bf7c10>],
     'medians': [<matplotlib.lines.Line2D at 0x1c608d99520>],
     'fliers': [<matplotlib.lines.Line2D at 0x1c608bea1c0>],
     'means': []}




    
![png](output_165_1.png)
    



```python

```


```python

```
